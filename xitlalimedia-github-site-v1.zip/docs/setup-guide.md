# Setup Guide

1. Upload all files to the repository root.
2. Verify `CNAME` contains `xitlalimedia.com`.
3. Enable GitHub Pages.
4. Test every navigation link.
5. Replace placeholder statistics and contact email when ready.
6. Add new team records to `data/teams.json`.
