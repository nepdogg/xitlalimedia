# Directory Structure

The public company website, generated team template, team data, and admin placeholder are intentionally separated. Company assets belong in `assets/`; future team-specific files belong in `team-assets/`.
