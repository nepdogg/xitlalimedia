# Xitlali Media Website

Initial static GitHub Pages website for **xitlalimedia.com**.

## Main pages
- Home
- Services
- Teams
- Portfolio
- About
- Contact
- 404

## Uploading to GitHub
Upload the contents of this folder to the root of the `xitlalimedia` repository.

In GitHub:
1. Open **Settings → Pages**.
2. Deploy from the `main` branch and `/root`.
3. Confirm the custom domain is `xitlalimedia.com`.
4. Enable **Enforce HTTPS** after DNS is connected.

## Important
The contact form currently opens the visitor's email application using `mailto:`. Replace this later with a proper form service or backend.

The `/admin/` page is a placeholder. Secure content editing and automatic team-site generation require a backend or authenticated GitHub workflow.
