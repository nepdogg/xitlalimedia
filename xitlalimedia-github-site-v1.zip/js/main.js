const XM = (() => {
  const page = document.body.dataset.page || "";
  const navItems = [
    ["Home", "index.html", "home"],
    ["Services", "services.html", "services"],
    ["Teams", "teams.html", "teams"],
    ["Portfolio", "portfolio.html", "portfolio"],
    ["About", "about.html", "about"],
    ["Contact", "contact.html", "contact"]
  ];

  function header() {
    const nav = navItems.map(([label, href, key]) =>
      `<a href="${href}" class="${page === key ? "active" : ""}">${label}</a>`
    ).join("");
    return `
      <header class="site-header">
        <div class="container nav-wrap">
          <a class="brand" href="index.html" aria-label="Xitlali Media home">
            <img src="assets/branding/favicons/favicon.png" alt="">
            <span>XITLALI<small>MEDIA</small></span>
          </a>
          <button class="nav-toggle" aria-label="Open navigation" aria-expanded="false">MENU</button>
          <nav class="nav-links" aria-label="Primary navigation">${nav}</nav>
        </div>
      </header>`;
  }

  function footer() {
    return `
      <footer class="site-footer">
        <div class="container">
          <div class="footer-grid">
            <div>
              <h3>Xitlali Media</h3>
              <p class="muted">Capturing moments. Creating legacies. Professional media production, team websites, and digital archives for local soccer.</p>
            </div>
            <div>
              <h3>Explore</h3>
              <ul class="list-clean">
                <li><a href="services.html">Services</a></li>
                <li><a href="teams.html">Teams</a></li>
                <li><a href="portfolio.html">Portfolio</a></li>
              </ul>
            </div>
            <div>
              <h3>Company</h3>
              <ul class="list-clean">
                <li><a href="about.html">About</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li><a href="admin/index.html">Admin</a></li>
              </ul>
            </div>
          </div>
          <div class="footer-bottom">© <span id="year"></span> Xitlali Media. All rights reserved.</div>
        </div>
      </footer>`;
  }

  function init() {
    document.getElementById("site-header")?.insertAdjacentHTML("afterbegin", header());
    document.getElementById("site-footer")?.insertAdjacentHTML("afterbegin", footer());
    document.getElementById("year").textContent = new Date().getFullYear();
    const toggle = document.querySelector(".nav-toggle");
    const nav = document.querySelector(".nav-links");
    toggle?.addEventListener("click", () => {
      nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(nav.classList.contains("open")));
    });
  }

  return { init };
})();
document.addEventListener("DOMContentLoaded", XM.init);