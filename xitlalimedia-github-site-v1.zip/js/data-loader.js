async function loadJSON(path) {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`Unable to load ${path}`);
  return res.json();
}

document.addEventListener("DOMContentLoaded", async () => {
  const serviceGrid = document.querySelector("[data-services]");
  if (serviceGrid) {
    try {
      const data = await loadJSON("data/services.json");
      serviceGrid.innerHTML = data.services.map(item => `
        <article class="card">
          <div class="icon">${item.icon}</div>
          <h3>${item.title}</h3>
          <p class="muted">${item.description}</p>
        </article>`).join("");
    } catch (error) {
      serviceGrid.innerHTML = `<div class="notice">Services are being prepared.</div>`;
    }
  }

  const teamGrid = document.querySelector("[data-teams]");
  if (teamGrid) {
    try {
      const data = await loadJSON("data/teams.json");
      teamGrid.innerHTML = data.teams.map(team => `
        <article class="card">
          <div class="team-badge">${team.name.split(/\s+/).map(x => x[0]).join("").slice(0,3)}</div>
          <p class="eyebrow" style="margin-top:20px">${team.type} site</p>
          <h3>${team.name}</h3>
          <p class="muted">${team.description}</p>
          <a class="btn btn-secondary" href="${team.url}" target="_blank" rel="noopener">Visit team website</a>
        </article>`).join("");
    } catch (error) {
      teamGrid.innerHTML = `<div class="empty-state">No team sites have been published yet.</div>`;
    }
  }

  const portfolioGrid = document.querySelector("[data-portfolio]");
  if (portfolioGrid) {
    try {
      const data = await loadJSON("data/portfolio.json");
      portfolioGrid.innerHTML = data.items.map(item => `
        <article class="card">
          <p class="eyebrow">${item.type}</p>
          <h3>${item.title}</h3>
          <p class="muted">${item.description}</p>
        </article>`).join("");
    } catch (error) {
      portfolioGrid.innerHTML = `<div class="notice">Portfolio items are being prepared.</div>`;
    }
  }
});